public class Triangle extends Shape {

    private Point a;
    private Point b;
    private Point c;

    public Triangle (){
        super();
        this.a = new Point();
        this.b = new Point();
        this.c = new Point();
    }

    public Triangle(double x, double y, Point a, Point b, Point c) {
        super(x,y);
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Point getA() {
        return a;
    }
    public void setA(Point a) {
        this.a = a;
    }
    public Point getB() {
        return b;
    }
    public void setB(Point b) {
        this.b = b;
    }
    public Point getC() {
        return c;
    }
    public void setC(Point c) {
        this.c = c;
    }
    public Point[] getABC() {
        return new Point[]{a, b, c};
    }
    public void setABC(Point a, Point b, Point c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double getHeight () {
        return this.b.distanceTo(a);
    }

    public double getBase () {
        return this.b.distanceTo(c);
    }

    @Override
    public Point getPosition(){
        return position;
    }

    @Override
    public double getArea () {
        return (getBase()*getHeight())/2;
    }

    @Override
    public double getPerimetro(){
        double hipote = Math.sqrt((getBase()*getBase())+(getHeight()*getHeight()));
        return getBase()+getHeight()+hipote;
    }
}
