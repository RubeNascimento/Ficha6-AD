public interface ShapeInterface {
    Point getPosition();
    double getArea();
    double getPerimetro();
}
