public abstract class Shape {
    protected Point position;

    public Shape() {
        this.position = new Point();
    }

    public Shape(double x, double y) {
        this.position = new Point(x, y);
    }


    public void setPosition(Point position) {
        this.position = position;
    }

    // métodos abstratos
    public abstract Point getPosition();
    public abstract double getArea();
    public abstract double getPerimetro();
}
