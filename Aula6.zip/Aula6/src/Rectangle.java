public class Rectangle extends Shape {

    private Point topLeftPoint;
    private double height;
    private double width;

    public Rectangle (){
        super();
        this.topLeftPoint = new Point();
        this.height = 0.0;
        this.width = 0.0;
    }

    public Rectangle(double x, double y,Point topLeftPoint, double height, double width) {
        super(x,y);
        this.topLeftPoint = topLeftPoint;
        this.height = height;
        this.width = width;
    }

    public Point getTopLeftPoint() {
        return topLeftPoint;
    }
    public void setTopLeftPoint(Point topLeftPoint) {
        this.topLeftPoint = topLeftPoint;
    }
    public double getHeight() {
        return height;
    }
    public void setHeight(double height) {
        this.height = height;
    }
    public double getWidth() {
        return width;
    }
    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    public Point getPosition() {
        return position;
    }

    @Override
    public double getArea () {
        return getHeight()*getWidth();
    }

    @Override
    public double getPerimetro () {
        return (getHeight()*2)+(getWidth()*2);
    }

    public boolean isIn (Point p) {
        Point bottomRight = new Point(topLeftPoint.getX()+getWidth(), topLeftPoint.getY()-getHeight());

        if (p.getX() < bottomRight.getX() && p.getX() > topLeftPoint.getX() && p.getY() > bottomRight.getY() && p.getY() < topLeftPoint.getY()) {
            return true;
        }
        else {
            return false;
        }
    }
}
